<?php
	echo '<section class="row"><article class="col col-sm-12"><div class="alert alert-danger">You are not authorize to view this page. Please contact system administrator for more information or to get access.</div></article></section>';
?>