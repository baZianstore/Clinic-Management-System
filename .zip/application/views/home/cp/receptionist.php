<?php
  echo anchor('patient/register','<span class="glyphicon glyphicon-user"></span> <br/>Register Patient',array("class"=>"btn btn-success btn-lg", "role"=>"button"));
?>
