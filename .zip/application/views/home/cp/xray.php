<?php
  echo anchor('xray/','<span class="glyphicon glyphicon-user"></span> <br/>X-rays',array("class"=>"btn btn-info btn-lg", "role"=>"button", "title"=>"List of All Xrays"));
  echo anchor('xray/new_xray','<span class="glyphicon glyphicon-user"></span> <br/>Register New X-ray',array("class"=>"btn btn-info btn-lg", "role"=>"button", "title"=>"Register New Xray to Database"));
?>
